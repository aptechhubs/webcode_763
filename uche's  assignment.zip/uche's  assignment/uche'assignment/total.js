function total() {
    var sum = 0;
    for (var i = 0; i <= 20; i++) {
        sum += i;
    }
    alert("Sum of number 1-20 is " + sum);
}
total();