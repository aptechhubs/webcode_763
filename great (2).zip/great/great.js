var comingfromhtml = document.getElementById("batchfile");
comingfromhtml.style.backgroundColor ="gold";