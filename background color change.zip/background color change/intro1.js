var selector = document.getElementById("tobescolor");
selector.addEventListener("change",function(){
	var index = this.selectedIndex;
	var myreal = this.options[index].value;
	console.log(typeof(myreal));
document.getElementById("tobechukwu").style.backgroundColor = myreal;
});